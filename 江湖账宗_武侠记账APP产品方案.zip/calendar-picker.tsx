import React, { useState, useMemo } from "react";
import { View, Text, Pressable, FlatList } from "react-native";
import { useColors } from "@/hooks/use-colors";

interface CalendarPickerProps {
  selectedDate: Date;
  onDateSelect: (date: Date) => void;
  transactionsByDate?: Record<string, { count: number; amount: number }>;
}

export function CalendarPicker({
  selectedDate,
  onDateSelect,
  transactionsByDate = {},
}: CalendarPickerProps) {
  const colors = useColors();
  const [currentMonth, setCurrentMonth] = useState(new Date(selectedDate));

  const daysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const firstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const days = useMemo(() => {
    const totalDays = daysInMonth(currentMonth);
    const firstDay = firstDayOfMonth(currentMonth);
    const result = [];

    // 前置空白
    for (let i = 0; i < firstDay; i++) {
      result.push(null);
    }

    // 日期
    for (let i = 1; i <= totalDays; i++) {
      result.push(i);
    }

    return result;
  }, [currentMonth]);

  const isDateSelected = (day: number) => {
    return (
      day === selectedDate.getDate() &&
      currentMonth.getMonth() === selectedDate.getMonth() &&
      currentMonth.getFullYear() === selectedDate.getFullYear()
    );
  };

  const getDateKey = (day: number) => {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    return date.toISOString().split("T")[0];
  };

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const handleSelectDay = (day: number) => {
    const newDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    onDateSelect(newDate);
  };

  const monthName = currentMonth.toLocaleDateString("zh-CN", {
    year: "numeric",
    month: "long",
  });

  const weekDays = ["日", "一", "二", "三", "四", "五", "六"];

  return (
    <View className="gap-4">
      {/* 月份导航 */}
      <View className="flex-row justify-between items-center">
        <Pressable
          onPress={handlePrevMonth}
          style={({ pressed }) => [
            {
              paddingVertical: 8,
              paddingHorizontal: 12,
              borderRadius: 6,
              backgroundColor: colors.surface,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Text className="text-lg font-bold text-foreground">{"<"}</Text>
        </Pressable>
        <Text className="text-lg font-bold text-foreground">{monthName}</Text>
        <Pressable
          onPress={handleNextMonth}
          style={({ pressed }) => [
            {
              paddingVertical: 8,
              paddingHorizontal: 12,
              borderRadius: 6,
              backgroundColor: colors.surface,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Text className="text-lg font-bold text-foreground">{">"}</Text>
        </Pressable>
      </View>

      {/* 周标题 */}
      <View className="flex-row">
        {weekDays.map((day) => (
          <View key={day} className="flex-1 items-center py-2">
            <Text className="text-xs font-bold text-muted">{day}</Text>
          </View>
        ))}
      </View>

      {/* 日期网格 */}
      <View className="gap-2">
        {Array.from({ length: Math.ceil(days.length / 7) }).map((_, weekIndex) => (
          <View key={weekIndex} className="flex-row gap-1">
            {days.slice(weekIndex * 7, (weekIndex + 1) * 7).map((day, dayIndex) => (
              <Pressable
                key={`${weekIndex}-${dayIndex}`}
                onPress={() => day && handleSelectDay(day)}
                disabled={!day}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    aspectRatio: 1,
                    borderRadius: 8,
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: day
                      ? isDateSelected(day)
                        ? colors.primary
                        : colors.surface
                      : "transparent",
                    opacity: pressed && day ? 0.8 : 1,
                  },
                ]}
              >
                {day && (
                  <View className="items-center gap-1">
                    <Text
                      className={`text-sm font-bold ${
                        isDateSelected(day) ? "text-white" : "text-foreground"
                      }`}
                    >
                      {day}
                    </Text>
                    {transactionsByDate[getDateKey(day)] && (
                      <Text
                        className={`text-xs ${
                          isDateSelected(day) ? "text-white" : "text-muted"
                        }`}
                      >
                        {transactionsByDate[getDateKey(day)].count}笔
                      </Text>
                    )}
                  </View>
                )}
              </Pressable>
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}
