import React, { useState, useContext } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Modal,
  Alert,
} from "react-native";
import { GameContext } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";
import { INCOME_CATEGORIES, EXPENSE_CATEGORIES, getCategoryEmoji } from "@/lib/categories";
import { CalendarPicker } from "./calendar-picker";

interface TransactionFormProps {
  onSuccess?: () => void;
  initialType?: "income" | "expense";
  initialDate?: Date;
}

export function TransactionForm({ onSuccess, initialType = "income", initialDate = new Date() }: TransactionFormProps) {
  const colors = useColors();
  const { addTransaction, gainExp, state } = useContext(GameContext);

  const [amount, setAmount] = useState("");
  const [type, setType] = useState<"income" | "expense">(initialType);
  const [category, setCategory] = useState(initialType === "income" ? "工資" : "飲食");
  const [note, setNote] = useState("");
  const [selectedDate, setSelectedDate] = useState(initialDate);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showExpGain, setShowExpGain] = useState(false);
  const [expGained, setExpGained] = useState(0);

  const categories = type === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const handleSubmit = () => {
    if (!amount || parseFloat(amount) <= 0) {
      Alert.alert("错误", "请输入正确的金额");
      return;
    }

    const numAmount = parseFloat(amount);
    const calculatedExp =
      type === "income" ? numAmount * 0.2 : numAmount * 0.05;
    const expInt = Math.floor(calculatedExp);

    // 添加账单
    addTransaction({
      type,
      amount: numAmount,
      category,
      note,
      date: selectedDate.toLocaleString("zh-CN"),
      expGained: expInt,
    });

    // 增加经验
    gainExp(calculatedExp);

    // 显示修为增长动画
    setExpGained(expInt);
    setShowExpGain(true);

    // 重置表单
    setAmount("");
    setNote("");
    setSelectedDate(new Date());
    setCategory(type === "income" ? "工资" : "饮食");

    setTimeout(() => {
      setShowExpGain(false);
      onSuccess?.();
    }, 2000);
  };

  return (
    <ScrollView
      className="flex-1"
      contentContainerStyle={{ paddingBottom: 20 }}
      showsVerticalScrollIndicator={false}
    >
      <View className="gap-4 p-4">
        {/* 类型选择 */}
        <View>
          <Text className="text-lg font-bold text-foreground mb-2">
            交易类型
          </Text>
          <View className="flex-row gap-2">
            {(["income", "expense"] as const).map((t) => (
              <Pressable
                key={t}
                onPress={() => {
                  setType(t);
                  setCategory(t === "income" ? "工资" : "饮食");
                }}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    borderRadius: 8,
                    backgroundColor:
                      type === t ? colors.primary : colors.surface,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <Text
                  className={`text-center font-bold ${
                    type === t ? "text-white" : "text-foreground"
                  }`}
                >
                  {t === "income" ? "💰 收入" : "💸 支出"}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* 金额输入 */}
        <View>
          <Text className="text-lg font-bold text-foreground mb-2">
            金额 (两)
          </Text>
          <TextInput
            className="border-2 border-border rounded-lg px-4 py-3 text-foreground text-base"
            placeholder="输入金额..."
            placeholderTextColor={colors.muted}
            keyboardType="decimal-pad"
            value={amount}
            onChangeText={setAmount}
          />
          {amount && (
            <Text className="text-sm text-muted mt-2">
              预计修为：
              <Text className="font-bold text-primary">
                +
                {Math.floor(
                  parseFloat(amount) * (type === "income" ? 0.2 : 0.05)
                )}
              </Text>
            </Text>
          )}
        </View>

        {/* 日期选择 */}
        <View>
          <Text className="text-lg font-bold text-foreground mb-2">
            日期
          </Text>
          <Pressable
            onPress={() => setShowCalendar(!showCalendar)}
            style={({ pressed }) => [{
              paddingVertical: 12,
              paddingHorizontal: 16,
              borderRadius: 8,
              borderWidth: 2,
              borderColor: colors.border,
              opacity: pressed ? 0.8 : 1,
            }]}
          >
            <Text className="text-foreground font-semibold">
              📅 {selectedDate.toLocaleDateString("zh-CN")}
            </Text>
          </Pressable>
          {showCalendar && (
            <View className="mt-4 p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
              <CalendarPicker
                selectedDate={selectedDate}
                onDateSelect={(date) => {
                  setSelectedDate(date);
                  setShowCalendar(false);
                }}
              />
            </View>
          )}
        </View>

        {/* 分类选择 */}
        <View>
          <Text className="text-lg font-bold text-foreground mb-2">
            分类
          </Text>
          <View className="flex-row flex-wrap gap-2">
            {categories.map((cat) => (
              <Pressable
                key={cat}
                onPress={() => setCategory(cat)}
                style={({ pressed }) => [
                  {
                    paddingVertical: 8,
                    paddingHorizontal: 12,
                    borderRadius: 20,
                    backgroundColor:
                      category === cat ? colors.primary : colors.surface,
                    borderWidth: category === cat ? 0 : 1,
                    borderColor: colors.border,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <Text
                  className={`text-sm font-semibold ${
                    category === cat ? "text-white" : "text-foreground"
                  }`}
                >
                  {getCategoryEmoji(type, cat)} {cat}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* 备注 */}
        <View>
          <Text className="text-lg font-bold text-foreground mb-2">
            备注 (可选)
          </Text>
          <TextInput
            className="border-2 border-border rounded-lg px-4 py-3 text-foreground text-base"
            placeholder="添加备注..."
            placeholderTextColor={colors.muted}
            value={note}
            onChangeText={setNote}
            multiline
            numberOfLines={3}
          />
        </View>

        {/* 提交按钮 */}
        <Pressable
          onPress={handleSubmit}
          style={({ pressed }) => [
            {
              paddingVertical: 14,
              paddingHorizontal: 16,
              borderRadius: 8,
              backgroundColor: colors.primary,
              opacity: pressed ? 0.9 : 1,
            },
          ]}
        >
          <Text className="text-center text-white font-bold text-lg">
            确认记账，提升修为
          </Text>
        </Pressable>
      </View>

      {/* 修为增长动画 */}
      <Modal visible={showExpGain} transparent animationType="fade">
        <View className="flex-1 items-center justify-center bg-black/50">
          <View className="bg-white rounded-lg p-8 items-center gap-4">
            <Text className="text-4xl font-bold text-primary">+{expGained}</Text>
            <Text className="text-xl font-bold text-foreground">修为增长！</Text>
            <Text className="text-base text-muted text-center">
              {type === "income" ? "财源广进，修为大增！" : "入世历练，修为增长！"}
            </Text>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}
