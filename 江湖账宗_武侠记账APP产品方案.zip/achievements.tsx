import React, { useContext } from "react";
import { View, Text, FlatList, Pressable } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { GameContext } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";

export default function AchievementsScreen() {
  const colors = useColors();
  const { state } = useContext(GameContext);

  const unlockedCount = state.achievements.filter((a) => a.unlocked).length;

  return (
    <ScreenContainer className="bg-background">
      <View className="gap-4 p-4 flex-1">
        <View className="gap-2">
          <Text className="text-2xl font-bold text-foreground">江湖成就</Text>
          <Text className="text-sm text-muted">
            已解锁 {unlockedCount} / {state.achievements.length} 个
          </Text>
        </View>

        <FlatList
          scrollEnabled={true}
          data={state.achievements}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <AchievementCard achievement={item} />
          )}
          contentContainerStyle={{ gap: 12 }}
        />
      </View>
    </ScreenContainer>
  );
}

function AchievementCard({
  achievement,
}: {
  achievement: { id: string; title: string; desc: string; unlocked: boolean; unlockedDate?: string };
}) {
  const colors = useColors();

  return (
    <Pressable
      style={({ pressed }) => [
        {
          paddingVertical: 12,
          paddingHorizontal: 16,
          borderRadius: 8,
          backgroundColor: achievement.unlocked ? colors.surface : colors.border,
          opacity: pressed ? 0.8 : 1,
          borderLeftWidth: 4,
          borderLeftColor: achievement.unlocked ? "#FFD700" : colors.border,
        },
      ]}
    >
      <View className="flex-row items-center justify-between gap-3">
        <View className="flex-1">
          <Text
            className={`text-base font-bold ${
              achievement.unlocked ? "text-foreground" : "text-muted"
            }`}
          >
            {achievement.unlocked ? "🏆" : "🔒"} {achievement.title}
          </Text>
          <Text className="text-sm text-muted mt-1">{achievement.desc}</Text>
          {achievement.unlocked && achievement.unlockedDate && (
            <Text className="text-xs text-muted mt-2">
              解锁于 {new Date(achievement.unlockedDate).toLocaleDateString("zh-CN")}
            </Text>
          )}
        </View>
      </View>
    </Pressable>
  );
}
