import React, { createContext, useReducer, useCallback, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

// 类型定义
export interface Transaction {
  id: string;
  type: "income" | "expense";
  amount: number;
  category: string;
  note: string;
  date: string;
  expGained: number;
}

export interface Achievement {
  id: string;
  title: string;
  desc: string;
  unlocked: boolean;
  unlockedDate?: string;
}

export interface CharacterState {
  name: string;
  level: number;
  exp: number;
  expNeeded: number;
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  stamina: number;
  maxStamina: number;
  prestige: number;
}

export interface GameState {
  character: CharacterState;
  transactions: Transaction[];
  achievements: Achievement[];
}

// 初始状态
const initialCharacter: CharacterState = {
  name: "无名大侠",
  level: 1,
  exp: 0,
  expNeeded: 100,
  hp: 100,
  maxHp: 100,
  atk: 10,
  def: 5,
  spd: 8,
  stamina: 10,
  maxStamina: 10,
  prestige: 0,
};

const initialState: GameState = {
  character: initialCharacter,
  transactions: [],
  achievements: [
    {
      id: "monthly-income",
      title: "月入千金",
      desc: "当月收入合计达到1000元以上",
      unlocked: false,
    },
    {
      id: "save-money",
      title: "节流大侠",
      desc: "当月支出控制在预算目标以内",
      unlocked: false,
    },
    {
      id: "hundred-records",
      title: "记账百遍",
      desc: "累计记账达到100笔",
      unlocked: false,
    },
  ],
};

// Action 类型
type GameAction =
  | { type: "ADD_TRANSACTION"; payload: Transaction }
  | { type: "GAIN_EXP"; payload: number }
  | { type: "LEVEL_UP" }
  | { type: "SET_CHARACTER_NAME"; payload: string }
  | { type: "USE_STAMINA"; payload: number }
  | { type: "RECOVER_STAMINA"; payload: number }
  | { type: "ADD_PRESTIGE"; payload: number }
  | { type: "UNLOCK_ACHIEVEMENT"; payload: string }
  | { type: "LOAD_STATE"; payload: GameState };

// Reducer
function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case "ADD_TRANSACTION": {
      return {
        ...state,
        transactions: [action.payload, ...state.transactions],
      };
    }

    case "GAIN_EXP": {
      let newExp = state.character.exp + action.payload;
      let newLevel = state.character.level;
      let newExpNeeded = state.character.expNeeded;
      let newHp = state.character.maxHp;
      let newMaxHp = state.character.maxHp;
      let newAtk = state.character.atk;
      let newDef = state.character.def;
      let newSpd = state.character.spd;

      // 处理升级
      while (newExp >= newExpNeeded) {
        newExp -= newExpNeeded;
        newLevel++;
        newExpNeeded = Math.floor(newExpNeeded * 1.2);
        newMaxHp += 20;
        newHp = newMaxHp;
        newAtk += 2;
        newDef += 1;
        newSpd += 1;
      }

      return {
        ...state,
        character: {
          ...state.character,
          exp: newExp,
          level: newLevel,
          expNeeded: newExpNeeded,
          hp: newHp,
          maxHp: newMaxHp,
          atk: newAtk,
          def: newDef,
          spd: newSpd,
        },
      };
    }

    case "LEVEL_UP": {
      const newExpNeeded = Math.floor(state.character.expNeeded * 1.2);
      return {
        ...state,
        character: {
          ...state.character,
          level: state.character.level + 1,
          exp: 0,
          expNeeded: newExpNeeded,
          maxHp: state.character.maxHp + 20,
          hp: state.character.maxHp + 20,
          atk: state.character.atk + 2,
          def: state.character.def + 1,
          spd: state.character.spd + 1,
        },
      };
    }

    case "SET_CHARACTER_NAME": {
      return {
        ...state,
        character: {
          ...state.character,
          name: action.payload,
        },
      };
    }

    case "USE_STAMINA": {
      return {
        ...state,
        character: {
          ...state.character,
          stamina: Math.max(0, state.character.stamina - action.payload),
        },
      };
    }

    case "RECOVER_STAMINA": {
      return {
        ...state,
        character: {
          ...state.character,
          stamina: Math.min(
            state.character.maxStamina,
            state.character.stamina + action.payload
          ),
        },
      };
    }

    case "ADD_PRESTIGE": {
      return {
        ...state,
        character: {
          ...state.character,
          prestige: state.character.prestige + action.payload,
        },
      };
    }

    case "UNLOCK_ACHIEVEMENT": {
      return {
        ...state,
        achievements: state.achievements.map((ach) =>
          ach.id === action.payload
            ? {
                ...ach,
                unlocked: true,
                unlockedDate: new Date().toISOString(),
              }
            : ach
        ),
      };
    }

    case "LOAD_STATE": {
      return action.payload;
    }

    default:
      return state;
  }
}

// Context
export const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
  addTransaction: (transaction: Omit<Transaction, "id">) => void;
  gainExp: (amount: number) => void;
  setCharacterName: (name: string) => void;
  useStamina: (amount: number) => void;
  recoverStamina: (amount: number) => void;
  addPrestige: (amount: number) => void;
  unlockAchievement: (id: string) => void;
  saveState: () => Promise<void>;
  loadState: () => Promise<void>;
}>({
  state: initialState,
  dispatch: () => {},
  addTransaction: () => {},
  gainExp: () => {},
  setCharacterName: () => {},
  useStamina: () => {},
  recoverStamina: () => {},
  addPrestige: () => {},
  unlockAchievement: () => {},
  saveState: async () => {},
  loadState: async () => {},
});

// Provider
export function GameProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  const addTransaction = useCallback((transaction: Omit<Transaction, "id">) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
    };
    dispatch({ type: "ADD_TRANSACTION", payload: newTransaction });
  }, []);

  const gainExp = useCallback((amount: number) => {
    dispatch({ type: "GAIN_EXP", payload: amount });
  }, []);

  const setCharacterName = useCallback((name: string) => {
    dispatch({ type: "SET_CHARACTER_NAME", payload: name });
  }, []);

  const useStamina = useCallback((amount: number) => {
    dispatch({ type: "USE_STAMINA", payload: amount });
  }, []);

  const recoverStamina = useCallback((amount: number) => {
    dispatch({ type: "RECOVER_STAMINA", payload: amount });
  }, []);

  const addPrestige = useCallback((amount: number) => {
    dispatch({ type: "ADD_PRESTIGE", payload: amount });
  }, []);

  const unlockAchievement = useCallback((id: string) => {
    dispatch({ type: "UNLOCK_ACHIEVEMENT", payload: id });
  }, []);

  const saveState = useCallback(async () => {
    try {
      await AsyncStorage.setItem("gameState", JSON.stringify(state));
    } catch (error) {
      console.error("Failed to save game state:", error);
    }
  }, [state]);

  const loadState = useCallback(async () => {
    try {
      const saved = await AsyncStorage.getItem("gameState");
      if (saved) {
        dispatch({ type: "LOAD_STATE", payload: JSON.parse(saved) });
      }
    } catch (error) {
      console.error("Failed to load game state:", error);
    }
  }, []);

  return (
    <GameContext.Provider
      value={{
        state,
        dispatch,
        addTransaction,
        gainExp,
        setCharacterName,
        useStamina,
        recoverStamina,
        addPrestige,
        unlockAchievement,
        saveState,
        loadState,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}
