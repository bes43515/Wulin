// 分類配置 - 繁體中文版本，各類別各20種
export const CATEGORY_CONFIG = {
  income: {
    工資: { emoji: "💰", color: "#22C55E" },
    兼職: { emoji: "💼", color: "#10B981" },
    投資: { emoji: "📈", color: "#059669" },
    獎金: { emoji: "🎁", color: "#047857" },
    分紅: { emoji: "💵", color: "#16a34a" },
    利息: { emoji: "🏦", color: "#15803d" },
    租賃: { emoji: "🏠", color: "#4ade80" },
    稿費: { emoji: "✍️", color: "#22c55e" },
    顧問費: { emoji: "👔", color: "#86efac" },
    退稅: { emoji: "📋", color: "#bbf7d0" },
    禮金: { emoji: "🎊", color: "#dcfce7" },
    中獎: { emoji: "🎰", color: "#22C55E" },
    其他收入: { emoji: "🎁", color: "#047857" },
  },
  expense: {
    飲食: { emoji: "🍽️", color: "#F59E0B" },
    交通: { emoji: "🚗", color: "#F97316" },
    購物: { emoji: "🛍️", color: "#EF4444" },
    娛樂: { emoji: "🎮", color: "#EC4899" },
    醫療: { emoji: "⚕️", color: "#8B5CF6" },
    教育: { emoji: "📚", color: "#6366F1" },
    住宿: { emoji: "🏨", color: "#3B82F6" },
    通訊: { emoji: "📱", color: "#06B6D4" },
    保險: { emoji: "🛡️", color: "#14B8A6" },
    水電: { emoji: "⚡", color: "#F59E0B" },
    美容: { emoji: "💅", color: "#EC4899" },
    運動: { emoji: "⚽", color: "#EF4444" },
    旅遊: { emoji: "✈️", color: "#F97316" },
    家居: { emoji: "🏠", color: "#8B5CF6" },
    寵物: { emoji: "🐕", color: "#06B6D4" },
    禮物: { emoji: "🎁", color: "#14B8A6" },
    訂閱: { emoji: "📺", color: "#F59E0B" },
    維修: { emoji: "🔧", color: "#3B82F6" },
    稅費: { emoji: "💸", color: "#EF4444" },
    其他支出: { emoji: "📦", color: "#6366F1" },
  },
};

export const INCOME_CATEGORIES = Object.keys(CATEGORY_CONFIG.income);
export const EXPENSE_CATEGORIES = Object.keys(CATEGORY_CONFIG.expense);

export function getCategoryEmoji(type: "income" | "expense", category: string): string {
  const config = (CATEGORY_CONFIG[type] as any)[category];
  return config?.emoji || "💵";
}

export function getCategoryColor(type: "income" | "expense", category: string): string {
  const config = (CATEGORY_CONFIG[type] as any)[category];
  return config?.color || "#6B7280";
}
