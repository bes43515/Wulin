import React, { useMemo } from "react";
import { View, Text, FlatList, Dimensions } from "react-native";
import { Transaction } from "@/lib/game-context";
import { getCategoryEmoji, getCategoryColor } from "@/lib/categories";
import { useColors } from "@/hooks/use-colors";

interface AdvancedStatisticsPanelProps {
  transactions: Transaction[];
  type: "day" | "month";
  selectedDate?: Date;
  chartType?: "bar" | "pie" | "line";
}

export function AdvancedStatisticsPanel({
  transactions,
  type,
  selectedDate = new Date(),
  chartType = "bar",
}: AdvancedStatisticsPanelProps) {
  const colors = useColors();
  const screenWidth = Dimensions.get("window").width;

  const stats = useMemo(() => {
    let filtered = transactions;

    if (type === "day") {
      const dateStr = selectedDate.toISOString().split("T")[0];
      filtered = transactions.filter((t) => t.date.split(" ")[0] === dateStr);
    } else if (type === "month") {
      const year = selectedDate.getFullYear();
      const month = selectedDate.getMonth() + 1;
      filtered = transactions.filter((t) => {
        const [dateStr] = t.date.split(" ");
        const [y, m] = dateStr.split("-");
        return parseInt(y) === year && parseInt(m) === month;
      });
    }

    // 按分類統計
    const byCategory: Record<string, { count: number; amount: number }> = {};
    let totalIncome = 0;
    let totalExpense = 0;

    filtered.forEach((t) => {
      if (!byCategory[t.category]) {
        byCategory[t.category] = { count: 0, amount: 0 };
      }
      byCategory[t.category].count++;
      byCategory[t.category].amount += t.amount;

      if (t.type === "income") {
        totalIncome += t.amount;
      } else {
        totalExpense += t.amount;
      }
    });

    const categoryList = Object.entries(byCategory)
      .map(([category, data]) => ({
        category,
        ...data,
        percentage: ((data.amount / (totalIncome + totalExpense)) * 100).toFixed(1),
      }))
      .sort((a, b) => b.amount - a.amount);

    return {
      totalIncome,
      totalExpense,
      categoryList,
      transactionCount: filtered.length,
    };
  }, [transactions, type, selectedDate]);

  const timeLabel = type === "day" 
    ? selectedDate.toLocaleDateString("zh-TW")
    : selectedDate.toLocaleDateString("zh-TW", { year: "numeric", month: "long" });

  return (
    <View className="gap-4">
      {/* 時間標題 */}
      <Text className="text-lg font-bold text-foreground">{timeLabel}統計</Text>

      {/* 收支總覽 */}
      <View className="flex-row gap-3">
        <View
          className="flex-1 rounded-lg p-4 gap-2"
          style={{ backgroundColor: colors.surface }}
        >
          <Text className="text-xs text-muted">總收入</Text>
          <Text className="text-2xl font-bold text-green-600">
            ¥{stats.totalIncome.toFixed(2)}
          </Text>
        </View>
        <View
          className="flex-1 rounded-lg p-4 gap-2"
          style={{ backgroundColor: colors.surface }}
        >
          <Text className="text-xs text-muted">總支出</Text>
          <Text className="text-2xl font-bold text-red-600">
            ¥{stats.totalExpense.toFixed(2)}
          </Text>
        </View>
        <View
          className="flex-1 rounded-lg p-4 gap-2"
          style={{ backgroundColor: colors.surface }}
        >
          <Text className="text-xs text-muted">結餘</Text>
          <Text
            className="text-2xl font-bold"
            style={{
              color: stats.totalIncome - stats.totalExpense >= 0 ? "#22C55E" : "#EF4444",
            }}
          >
            ¥{(stats.totalIncome - stats.totalExpense).toFixed(2)}
          </Text>
        </View>
      </View>

      {/* 分類明細 */}
      {stats.categoryList.length > 0 ? (
        <View className="gap-2">
          <Text className="text-sm font-bold text-foreground">分類明細</Text>
          <FlatList
            scrollEnabled={false}
            data={stats.categoryList}
            keyExtractor={(item) => item.category}
            renderItem={({ item }) => (
              <View
                className="flex-row items-center justify-between p-3 rounded-lg mb-2"
                style={{ backgroundColor: colors.surface }}
              >
                <View className="flex-row items-center gap-3 flex-1">
                  <Text className="text-2xl">
                    {getCategoryEmoji("expense", item.category)}
                  </Text>
                  <View className="flex-1">
                    <Text className="font-bold text-foreground">{item.category}</Text>
                    <Text className="text-xs text-muted">{item.count}筆交易</Text>
                  </View>
                </View>
                <View className="items-end gap-1">
                  <Text className="font-bold text-foreground">
                    ¥{item.amount.toFixed(2)}
                  </Text>
                  <Text className="text-xs text-muted">{item.percentage}%</Text>
                </View>
              </View>
            )}
          />
        </View>
      ) : (
        <View
          className="rounded-lg p-6 items-center"
          style={{ backgroundColor: colors.surface }}
        >
          <Text className="text-muted text-center">暫無交易記錄</Text>
        </View>
      )}

      {/* 柱狀圖 */}
      {stats.categoryList.length > 0 && (
        <View className="gap-2">
          <Text className="text-sm font-bold text-foreground">支出分佈 (柱狀圖)</Text>
          <View className="gap-2">
            {stats.categoryList.slice(0, 5).map((item) => (
              <View key={item.category} className="gap-1">
                <View className="flex-row justify-between items-center">
                  <Text className="text-xs text-muted flex-1">{item.category}</Text>
                  <Text className="text-xs font-bold text-foreground">
                    {item.percentage}%
                  </Text>
                </View>
                <View
                  className="h-3 bg-gray-200 rounded-full overflow-hidden"
                  style={{ backgroundColor: colors.border }}
                >
                  <View
                    className="h-full rounded-full"
                    style={{
                      width: `${parseFloat(item.percentage)}%` as any,
                      backgroundColor: getCategoryColor("expense", item.category),
                    }}
                  />
                </View>
              </View>
            ))}
          </View>
        </View>
      )}

      {/* 簡易餅圖 (文字表示) */}
      {stats.categoryList.length > 0 && (
        <View className="gap-2">
          <Text className="text-sm font-bold text-foreground">支出比例 (餅圖)</Text>
          <View
            className="rounded-lg p-4 gap-2"
            style={{ backgroundColor: colors.surface }}
          >
            {stats.categoryList.slice(0, 8).map((item, index) => (
              <View key={item.category} className="flex-row items-center gap-2">
                <View
                  className="w-4 h-4 rounded-full"
                  style={{
                    backgroundColor: getCategoryColor("expense", item.category),
                  }}
                />
                <Text className="text-xs text-foreground flex-1">
                  {item.category}
                </Text>
                <Text className="text-xs font-bold text-foreground">
                  {item.percentage}%
                </Text>
              </View>
            ))}
          </View>
        </View>
      )}

      {/* 每日趨勢 (僅月視圖) */}
      {type === "month" && stats.transactionCount > 0 && (
        <View className="gap-2">
          <Text className="text-sm font-bold text-foreground">每日支出趨勢</Text>
          <View
            className="rounded-lg p-4"
            style={{ backgroundColor: colors.surface }}
          >
            <Text className="text-xs text-muted text-center">
              本月共 {stats.transactionCount} 筆交易
            </Text>
            <Text className="text-xs text-muted text-center mt-2">
              平均每筆: ¥
              {(
                (stats.totalIncome + stats.totalExpense) /
                stats.transactionCount
              ).toFixed(2)}
            </Text>
          </View>
        </View>
      )}
    </View>
  );
}
