import React, { useContext, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  FlatList,
  RefreshControl,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { CharacterPanel } from "@/components/character-panel";
import { GameContext } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { state, saveState, loadState } = useContext(GameContext);
  const [refreshing, setRefreshing] = React.useState(false);

  useEffect(() => {
    loadState();
  }, []);

  useEffect(() => {
    saveState();
  }, [state]);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  }, []);

  const recentTransactions = state.transactions.slice(0, 5);

  return (
    <ScreenContainer
      className="bg-background"
      containerClassName="bg-background"
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View className="gap-6 p-4">
          {/* 角色面板 */}
          <View
            className="rounded-lg p-4"
            style={{ backgroundColor: colors.surface }}
          >
            <CharacterPanel />
          </View>

          {/* 快速操作 */}
          <View className="flex-row gap-3">
            <Pressable
              onPress={() => router.push("/(tabs)/accounting")}
              style={({ pressed }) => [
                {
                  flex: 1,
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                  borderRadius: 8,
                  backgroundColor: colors.primary,
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <Text className="text-center text-white font-bold">
                📝 记账
              </Text>
            </Pressable>
            <Pressable
              onPress={() => router.push("/(tabs)/battle")}
              style={({ pressed }) => [
                {
                  flex: 1,
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                  borderRadius: 8,
                  backgroundColor: "#DC143C",
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <Text className="text-center text-white font-bold">
                ⚔️ 切磋
              </Text>
            </Pressable>
          </View>

          {/* 最近交易 */}
          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">
              最近交易记录
            </Text>
            {recentTransactions.length === 0 ? (
              <View
                className="rounded-lg p-6 items-center"
                style={{ backgroundColor: colors.surface }}
              >
                <Text className="text-muted text-center">
                  暂无记录，快去记一笔吧！
                </Text>
              </View>
            ) : (
              <FlatList
                scrollEnabled={false}
                data={recentTransactions}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <View
                    className={`rounded-lg p-3 flex-row justify-between items-center border-l-4 ${
                      item.type === "income"
                        ? "bg-green-50 border-green-500"
                        : "bg-red-50 border-red-500"
                    }`}
                  >
                    <View className="flex-1">
                      <Text className="font-bold text-foreground">
                        {item.note || (item.type === "income" ? "收入" : "支出")}
                      </Text>
                      <Text className="text-xs text-muted">{item.date}</Text>
                    </View>
                    <View className="items-end">
                      <Text
                        className={`font-bold ${
                          item.type === "income"
                            ? "text-green-600"
                            : "text-red-600"
                        }`}
                      >
                        {item.type === "income" ? "+" : "-"}
                        {item.amount} 两
                      </Text>
                      <Text className="text-xs text-blue-600">
                        修为 +{item.expGained}
                      </Text>
                    </View>
                  </View>
                )}
              />
            )}
          </View>

          {/* 本月统计 */}
          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">
              本月收支统计
            </Text>
            <View className="flex-row gap-3">
              <StatCard
                label="总收入"
                value={`¥${state.transactions
                  .filter((t) => t.type === "income")
                  .reduce((sum, t) => sum + t.amount, 0)
                  .toFixed(2)}`}
                color="#22C55E"
              />
              <StatCard
                label="总支出"
                value={`¥${state.transactions
                  .filter((t) => t.type === "expense")
                  .reduce((sum, t) => sum + t.amount, 0)
                  .toFixed(2)}`}
                color="#EF4444"
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

interface StatCardProps {
  label: string;
  value: string;
  color: string;
}

function StatCard({ label, value, color }: StatCardProps) {
  const colors = useColors();

  return (
    <View
      className="flex-1 rounded-lg p-4 items-center gap-2"
      style={{ backgroundColor: colors.surface }}
    >
      <Text className="text-xs text-muted">{label}</Text>
      <Text className="text-2xl font-bold" style={{ color }}>
        {value}
      </Text>
    </View>
  );
}
