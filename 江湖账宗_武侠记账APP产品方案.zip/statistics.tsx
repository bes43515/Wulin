import React, { useContext, useState } from "react";
import { View, Text, Pressable, ScrollView } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { AdvancedStatisticsPanel } from "@/components/advanced-statistics-panel";
import { GameContext } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";

export default function StatisticsScreen() {
  const colors = useColors();
  const { state } = useContext(GameContext);
  const [viewType, setViewType] = useState<"day" | "month">("month");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [chartType, setChartType] = useState<"bar" | "pie" | "line">("bar");

  const handlePrevDay = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() - 1);
    setSelectedDate(newDate);
  };

  const handleNextDay = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + 1);
    setSelectedDate(newDate);
  };

  const handlePrevMonth = () => {
    const newDate = new Date(selectedDate);
    newDate.setMonth(newDate.getMonth() - 1);
    setSelectedDate(newDate);
  };

  const handleNextMonth = () => {
    const newDate = new Date(selectedDate);
    newDate.setMonth(newDate.getMonth() + 1);
    setSelectedDate(newDate);
  };

  const dateLabel = viewType === "day"
    ? selectedDate.toLocaleDateString("zh-TW")
    : selectedDate.toLocaleDateString("zh-TW", { year: "numeric", month: "long" });

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        <View className="gap-4 p-4">
          {/* 标题 */}
        <View className="gap-2">
          <Text className="text-2xl font-bold text-foreground">賬單統計</Text>
          <Text className="text-sm text-muted">
            查看您的收支明細和分類分析
          </Text>
        </View>

          {/* 视图切换 */}
          <View className="flex-row gap-2">
            <Pressable
              onPress={() => setViewType("day")}
              style={({ pressed }) => [
                {
                  flex: 1,
                  paddingVertical: 10,
                  paddingHorizontal: 16,
                  borderRadius: 8,
                  backgroundColor:
                    viewType === "day" ? colors.primary : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text
                className={`text-center font-bold ${
                  viewType === "day" ? "text-white" : "text-foreground"
                }`}
              >
                📅 日報表
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setViewType("month")}
              style={({ pressed }) => [
                {
                  flex: 1,
                  paddingVertical: 10,
                  paddingHorizontal: 16,
                  borderRadius: 8,
                  backgroundColor:
                    viewType === "month" ? colors.primary : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text
                className={`text-center font-bold ${
                  viewType === "month" ? "text-white" : "text-foreground"
                }`}
              >
                📊 月報表
              </Text>
            </Pressable>
          </View>

          {/* 日期导航 */}
          <View className="flex-row justify-between items-center gap-2">
            <Pressable
              onPress={viewType === "day" ? handlePrevDay : handlePrevMonth}
              style={({ pressed }) => [
                {
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                  borderRadius: 6,
                  backgroundColor: colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text className="text-lg font-bold text-foreground">{"<"}</Text>
            </Pressable>
            <Text className="text-lg font-bold text-foreground flex-1 text-center">
              {dateLabel}
            </Text>
            <Pressable
              onPress={viewType === "day" ? handleNextDay : handleNextMonth}
              style={({ pressed }) => [
                {
                  paddingVertical: 8,
                  paddingHorizontal: 12,
                  borderRadius: 6,
                  backgroundColor: colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <Text className="text-lg font-bold text-foreground">{">"}</Text>
            </Pressable>
          </View>

          {/* 統計面板 */}
          <View
            className="rounded-lg p-4"
            style={{ backgroundColor: colors.surface }}
          >
            <AdvancedStatisticsPanel
              transactions={state.transactions}
              type={viewType}
              selectedDate={selectedDate}
              chartType={chartType}
            />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
