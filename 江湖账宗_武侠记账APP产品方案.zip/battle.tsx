import React, { useState, useContext, useEffect } from "react";
import { View, Text, Pressable, Alert } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { BattleAnimation, BattleLog } from "@/components/battle-animation";
import { GameContext } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";

interface Enemy {
  name: string;
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
}

const BATTLE_MOVES = [
  "【铁算盘】",
  "【碎银掌】",
  "【守财金钟罩】",
  "【算盘错骨手】",
];

export default function BattleScreen() {
  const colors = useColors();
  const { state, useStamina, addPrestige } = useContext(GameContext);
  const [isBattling, setIsBattling] = useState(false);
  const [battleLogs, setBattleLogs] = useState<BattleLog[]>([]);
  const [playerHp, setPlayerHp] = useState(state.character.hp);
  const [enemyHp, setEnemyHp] = useState(0);
  const [enemy, setEnemy] = useState<Enemy | null>(null);

  const startBattle = () => {
    if (state.character.stamina <= 0) {
      Alert.alert("体力不足", "请先去记账修炼，恢复体力吧！");
      return;
    }

    // 生成敌人
    const newEnemy: Enemy = {
      name: "江湖路人",
      hp: 50 + state.character.level * 10,
      maxHp: 50 + state.character.level * 10,
      atk: 5 + state.character.level,
      def: 2 + Math.floor(state.character.level / 2),
      spd: 5 + Math.floor(state.character.level / 2),
    };

    setEnemy(newEnemy);
    setPlayerHp(state.character.hp);
    setEnemyHp(newEnemy.hp);
    setBattleLogs([]);
    setIsBattling(true);
    useStamina(1);

    // 开始战斗
    simulateBattle(state.character, newEnemy);
  };

  const simulateBattle = (player: any, enemy: Enemy) => {
    let myHp = player.hp;
    let theirHp = enemy.hp;
    let logs: BattleLog[] = [];
    let turn = 1;

    const battleInterval = setInterval(() => {
      // 决定出手顺序
      const playerFirst = player.spd >= enemy.spd;
      const isPlayerTurn = playerFirst ? turn % 2 !== 0 : turn % 2 === 0;

      if (isPlayerTurn) {
        // 玩家攻击
        const damage = Math.max(
          1,
          player.atk - enemy.def + Math.floor(Math.random() * 3)
        );
        theirHp -= damage;
        const move = BATTLE_MOVES[Math.floor(Math.random() * BATTLE_MOVES.length)];
        logs.push({
          id: `${turn}-player`,
          message: `第 ${turn} 回合：你使出${move}，对对手造成 ${damage} 点伤害！`,
          type: "damage",
        });
        setEnemyHp(Math.max(0, theirHp));
      } else {
        // 敌人攻击
        const damage = Math.max(
          1,
          enemy.atk - player.def + Math.floor(Math.random() * 3)
        );
        myHp -= damage;
        logs.push({
          id: `${turn}-enemy`,
          message: `第 ${turn} 回合：对手使出一招基础长拳，对你造成 ${damage} 点伤害！`,
          type: "damage",
        });
        setPlayerHp(Math.max(0, myHp));
      }

      setBattleLogs([...logs]);

      if (myHp <= 0 || theirHp <= 0) {
        clearInterval(battleInterval);
        if (myHp > 0) {
          logs.push({
            id: "result-win",
            message: "切磋获胜！声望 +10",
            type: "result",
          });
          addPrestige(10);
        } else {
          logs.push({
            id: "result-lose",
            message: "切磋失败，技不如人...",
            type: "result",
          });
        }
        setBattleLogs([...logs]);
        setIsBattling(false);
      }

      turn++;
    }, 1000);
  };

  const handleBattleEnd = () => {
    setBattleLogs([]);
    setIsBattling(false);
    setEnemy(null);
  };

  return (
    <ScreenContainer className="bg-background">
      <View className="gap-4 p-4 flex-1">
        <View className="gap-2">
          <Text className="text-2xl font-bold text-foreground">江湖切磋</Text>
          <Text className="text-sm text-muted">
            体力: {state.character.stamina} / {state.character.maxStamina}
          </Text>
        </View>

        {!isBattling && !enemy ? (
          <View
            className="flex-1 rounded-lg p-6 items-center justify-center gap-4"
            style={{ backgroundColor: colors.surface }}
          >
            <Text className="text-lg text-foreground text-center">
              准备好与江湖同道切磋了吗？
            </Text>
            <Pressable
              onPress={startBattle}
              disabled={state.character.stamina <= 0}
              style={({ pressed }) => [
                {
                  paddingVertical: 14,
                  paddingHorizontal: 28,
                  borderRadius: 8,
                  backgroundColor:
                    state.character.stamina <= 0 ? colors.border : colors.primary,
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <Text className="text-white font-bold text-lg">
                发起切磋
              </Text>
            </Pressable>
          </View>
        ) : (
          <View
            className="flex-1 rounded-lg p-4"
            style={{ backgroundColor: colors.surface }}
          >
            {enemy && (
              <BattleAnimation
                playerHp={playerHp}
                playerMaxHp={state.character.hp}
                enemyHp={enemyHp}
                enemyMaxHp={enemy.maxHp}
                battleLogs={battleLogs}
                isAnimating={isBattling}
                onBattleEnd={handleBattleEnd}
              />
            )}
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}
