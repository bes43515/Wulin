import React, { useContext, useState, useMemo } from "react";
import { View, Text, Pressable, Modal, ScrollView } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { CalendarPicker } from "@/components/calendar-picker";
import { TransactionForm } from "@/components/transaction-form";
import { GameContext } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";

export default function AccountingCalendarScreen() {
  const colors = useColors();
  const { state } = useContext(GameContext);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<"income" | "expense" | null>(null);

  // 計算每日交易統計
  const transactionsByDate = useMemo(() => {
    const result: Record<string, { count: number; amount: number }> = {};
    state.transactions.forEach((t) => {
      const dateKey = t.date.split(" ")[0];
      if (!result[dateKey]) {
        result[dateKey] = { count: 0, amount: 0 };
      }
      result[dateKey].count++;
      result[dateKey].amount += t.amount;
    });
    return result;
  }, [state.transactions]);

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
  };

  const handleOpenForm = (type: "income" | "expense") => {
    setFormType(type);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setFormType(null);
  };

  const selectedDateStr = selectedDate.toLocaleDateString("zh-TW");
  const selectedDateTransactions = state.transactions.filter(
    (t) => t.date.split(" ")[0] === selectedDate.toISOString().split("T")[0]
  );

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        <View className="gap-4 p-4">
          {/* 標題 */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">記帳日曆</Text>
            <Text className="text-sm text-muted">
              點選日期記帳或查看該日交易
            </Text>
          </View>

          {/* 日曆選擇器 */}
          <View
            className="rounded-lg p-4"
            style={{ backgroundColor: colors.surface }}
          >
            <CalendarPicker
              selectedDate={selectedDate}
              onDateSelect={handleDateSelect}
              transactionsByDate={transactionsByDate}
            />
          </View>

          {/* 選中日期信息 */}
          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">
              {selectedDateStr}
            </Text>

            {/* 快速操作按鈕 */}
            <View className="flex-row gap-2">
              <Pressable
                onPress={() => handleOpenForm("income")}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    borderRadius: 8,
                    backgroundColor: "#22C55E",
                    opacity: pressed ? 0.9 : 1,
                  },
                ]}
              >
                <Text className="text-center text-white font-bold">
                  💰 新增收入
                </Text>
              </Pressable>
              <Pressable
                onPress={() => handleOpenForm("expense")}
                style={({ pressed }) => [
                  {
                    flex: 1,
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    borderRadius: 8,
                    backgroundColor: "#EF4444",
                    opacity: pressed ? 0.9 : 1,
                  },
                ]}
              >
                <Text className="text-center text-white font-bold">
                  💸 新增支出
                </Text>
              </Pressable>
            </View>

            {/* 該日交易列表 */}
            {selectedDateTransactions.length > 0 ? (
              <View className="gap-2">
                <Text className="text-sm font-bold text-foreground">
                  本日交易 ({selectedDateTransactions.length}筆)
                </Text>
                {selectedDateTransactions.map((transaction, index) => (
                  <View
                    key={index}
                    className="flex-row justify-between items-center p-3 rounded-lg"
                    style={{ backgroundColor: colors.surface }}
                  >
                    <View className="flex-1">
                      <Text className="font-bold text-foreground">
                        {transaction.category}
                      </Text>
                      {transaction.note && (
                        <Text className="text-xs text-muted mt-1">
                          {transaction.note}
                        </Text>
                      )}
                    </View>
                    <Text
                      className="font-bold text-lg"
                      style={{
                        color:
                          transaction.type === "income"
                            ? "#22C55E"
                            : "#EF4444",
                      }}
                    >
                      {transaction.type === "income" ? "+" : "-"}¥
                      {transaction.amount.toFixed(2)}
                    </Text>
                  </View>
                ))}
              </View>
            ) : (
              <View
                className="rounded-lg p-6 items-center"
                style={{ backgroundColor: colors.surface }}
              >
                <Text className="text-muted text-center">
                  該日暫無交易，點選上方按鈕新增
                </Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>

      {/* 記帳表單Modal */}
      <Modal
        visible={showForm}
        animationType="slide"
        transparent={true}
        onRequestClose={handleCloseForm}
      >
        <View
          className="flex-1"
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            justifyContent: "flex-end",
          }}
        >
          <View
            className="rounded-t-3xl p-4 max-h-5/6"
            style={{ backgroundColor: colors.background }}
          >
            <View className="flex-row justify-between items-center mb-4">
              <Text className="text-xl font-bold text-foreground">
                {formType === "income" ? "💰 新增收入" : "💸 新增支出"}
              </Text>
              <Pressable
                onPress={handleCloseForm}
                style={({ pressed }) => [
                  {
                    paddingVertical: 8,
                    paddingHorizontal: 12,
                    borderRadius: 6,
                    backgroundColor: colors.surface,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <Text className="text-lg font-bold text-foreground">✕</Text>
              </Pressable>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <TransactionForm
                initialType={formType || "income"}
                initialDate={selectedDate}
                onSuccess={() => {
                  handleCloseForm();
                }}
              />
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
