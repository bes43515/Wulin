import React from "react";
import { View, Text } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { TransactionForm } from "@/components/transaction-form";
import { useColors } from "@/hooks/use-colors";

export default function AccountingScreen() {
  const colors = useColors();

  return (
    <ScreenContainer className="bg-background">
      <View className="gap-4 p-4 flex-1">
        <View className="gap-2">
          <Text className="text-2xl font-bold text-foreground">记账表单</Text>
          <Text className="text-sm text-muted">
            记录一笔交易，自动计算修为
          </Text>
        </View>

        <View
          className="flex-1 rounded-lg p-4"
          style={{ backgroundColor: colors.surface }}
        >
          <TransactionForm />
        </View>
      </View>
    </ScreenContainer>
  );
}
