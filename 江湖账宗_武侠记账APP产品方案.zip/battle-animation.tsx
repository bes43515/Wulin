import React, { useState, useEffect } from "react";
import { View, Text, Image, Animated, Pressable, ScrollView } from "react-native";
import { useColors } from "@/hooks/use-colors";

export interface BattleLog {
  id: string;
  message: string;
  type: "action" | "damage" | "defense" | "result";
}

interface BattleAnimationProps {
  playerHp: number;
  playerMaxHp: number;
  enemyHp: number;
  enemyMaxHp: number;
  battleLogs: BattleLog[];
  isAnimating: boolean;
  onBattleEnd?: () => void;
}

export function BattleAnimation({
  playerHp,
  playerMaxHp,
  enemyHp,
  enemyMaxHp,
  battleLogs,
  isAnimating,
  onBattleEnd,
}: BattleAnimationProps) {
  const colors = useColors();
  const [playerFlash, setPlayerFlash] = useState(false);
  const [enemyFlash, setEnemyFlash] = useState(false);

  useEffect(() => {
    if (battleLogs.length > 0) {
      const lastLog = battleLogs[battleLogs.length - 1];
      if (lastLog.type === "damage") {
        if (lastLog.message.includes("你")) {
          setEnemyFlash(true);
          setTimeout(() => setEnemyFlash(false), 300);
        } else {
          setPlayerFlash(true);
          setTimeout(() => setPlayerFlash(false), 300);
        }
      }
    }
  }, [battleLogs]);

  const playerHpPercent = (playerHp / playerMaxHp) * 100;
  const enemyHpPercent = (enemyHp / enemyMaxHp) * 100;

  return (
    <View className="gap-4 flex-1">
      {/* 对战角色区域 */}
      <View className="flex-row justify-between items-start gap-4 py-4 px-2">
        {/* 玩家角色 */}
        <View className="items-center gap-2 flex-1">
          <View
            className={`w-20 h-20 rounded-lg overflow-hidden ${
              playerFlash ? "bg-red-500" : "bg-gray-100"
            }`}
          >
            <Image
              source={{ uri: "/manus-storage/player-character_4c01b758.png" }}
              style={{ width: "100%", height: "100%" }}
            />
          </View>
          <Text className="font-bold text-foreground">你</Text>
          <View className="w-full gap-1">
            <View className="flex-row justify-between items-center">
              <Text className="text-xs text-muted">HP</Text>
              <Text className="text-xs font-bold text-red-600">
                {playerHp} / {playerMaxHp}
              </Text>
            </View>
            <View
              className="h-2 bg-border rounded-full overflow-hidden"
              style={{ backgroundColor: colors.border }}
            >
              <View
                className="h-full bg-red-500 rounded-full"
                style={{ width: `${playerHpPercent}%` }}
              />
            </View>
          </View>
        </View>

        {/* VS */}
        <View className="items-center justify-center py-8">
          <Text className="text-2xl font-bold text-muted">VS</Text>
        </View>

        {/* 敌人角色 */}
        <View className="items-center gap-2 flex-1">
          <View
            className={`w-20 h-20 rounded-lg overflow-hidden ${
              enemyFlash ? "bg-red-500" : "bg-gray-100"
            }`}
          >
            <Image
              source={{ uri: "/manus-storage/enemy-character_58514f28.png" }}
              style={{ width: "100%", height: "100%" }}
            />
          </View>
          <Text className="font-bold text-foreground">江湖路人</Text>
          <View className="w-full gap-1">
            <View className="flex-row justify-between items-center">
              <Text className="text-xs text-muted">HP</Text>
              <Text className="text-xs font-bold text-red-600">
                {enemyHp} / {enemyMaxHp}
              </Text>
            </View>
            <View
              className="h-2 bg-border rounded-full overflow-hidden"
              style={{ backgroundColor: colors.border }}
            >
              <View
                className="h-full bg-red-500 rounded-full"
                style={{ width: `${enemyHpPercent}%` }}
              />
            </View>
          </View>
        </View>
      </View>

      {/* 战斗日志 */}
      <View
        className="flex-1 rounded-lg p-3 gap-2"
        style={{ backgroundColor: colors.surface }}
      >
        <Text className="text-sm font-bold text-foreground mb-2">
          战斗进程
        </Text>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 8 }}
        >
          {battleLogs.length === 0 ? (
            <Text className="text-xs text-muted text-center py-4">
              准备开始对战...
            </Text>
          ) : (
            battleLogs.map((log) => (
              <BattleLogEntry key={log.id} log={log} />
            ))
          )}
        </ScrollView>
      </View>

      {/* 状态提示 */}
      {!isAnimating && battleLogs.length > 0 && (
        <View className="items-center gap-2">
          {playerHp <= 0 ? (
            <Text className="text-lg font-bold text-red-600">
              切磋失败，技不如人...
            </Text>
          ) : enemyHp <= 0 ? (
            <Text className="text-lg font-bold text-green-600">
              切磋获胜！声望 +10
            </Text>
          ) : null}
          <Pressable
            onPress={onBattleEnd}
            style={({ pressed }) => [
              {
                paddingVertical: 10,
                paddingHorizontal: 20,
                borderRadius: 6,
                backgroundColor: colors.primary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            <Text className="text-white font-bold text-center">离开擂台</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

function BattleLogEntry({ log }: { log: BattleLog }) {
  const colors = useColors();

  let textColor = colors.foreground;
  if (log.type === "damage") textColor = "#EF4444";
  if (log.type === "defense") textColor = "#22C55E";
  if (log.type === "result") textColor = "#F59E0B";

  return (
    <Text
      className="text-xs leading-relaxed"
      style={{ color: textColor }}
    >
      {log.message}
    </Text>
  );
}
