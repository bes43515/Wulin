import React, { useContext, useMemo } from "react";
import { View, Text, Image } from "react-native";
import { GameContext, CharacterState } from "@/lib/game-context";
import { useColors } from "@/hooks/use-colors";

function getTitle(level: number): string {
  if (level < 10) return "江湖新手";
  if (level < 30) return "江湖游侠";
  if (level < 60) return "武林高手";
  if (level < 90) return "一代宗师";
  return "武林盟主";
}

export function CharacterPanel() {
  const colors = useColors();
  const { state } = useContext(GameContext);
  const { character } = state;

  const expProgress = useMemo(() => {
    return (character.exp / character.expNeeded) * 100;
  }, [character.exp, character.expNeeded]);

  const title = useMemo(() => getTitle(character.level), [character.level]);

  return (
    <View className="gap-4">
      {/* 角色头部 */}
      <View className="items-center gap-2 pb-4 border-b border-border">
        <Image
          source={{ uri: "/manus-storage/player-character_4c01b758.png" }}
          style={{ width: 80, height: 80 }}
        />
        <Text className="text-2xl font-bold text-foreground">
          {character.name}
        </Text>
        <Text className="text-sm font-semibold text-primary">{title}</Text>
      </View>

      {/* 等级与经验 */}
      <View className="gap-2">
        <View className="flex-row justify-between items-center">
          <Text className="font-bold text-foreground">
            等级 {character.level}
          </Text>
          <Text className="text-sm text-muted">
            {Math.floor(character.exp)} / {character.expNeeded}
          </Text>
        </View>
        <View
          className="h-2 bg-border rounded-full overflow-hidden"
          style={{ backgroundColor: colors.border }}
        >
          <View
            className="h-full bg-primary rounded-full"
            style={{ width: `${expProgress}%` }}
          />
        </View>
      </View>

      {/* 属性卡片 */}
      <View className="grid grid-cols-2 gap-3">
        <AttributeCard
          label="气血"
          value={character.hp}
          max={character.maxHp}
          icon="❤️"
          color="#EF4444"
        />
        <AttributeCard
          label="攻击"
          value={character.atk}
          icon="⚔️"
          color="#3B82F6"
        />
        <AttributeCard
          label="防御"
          value={character.def}
          icon="🛡️"
          color="#22C55E"
        />
        <AttributeCard
          label="攻速"
          value={character.spd}
          icon="⚡"
          color="#F59E0B"
        />
      </View>

      {/* 其他信息 */}
      <View className="gap-2 pt-2 border-t border-border">
        <InfoRow label="江湖体力" value={`${character.stamina} / ${character.maxStamina}`} />
        <InfoRow label="江湖声望" value={character.prestige.toString()} />
      </View>
    </View>
  );
}

interface AttributeCardProps {
  label: string;
  value: number;
  max?: number;
  icon: string;
  color: string;
}

function AttributeCard({ label, value, max, icon, color }: AttributeCardProps) {
  const colors = useColors();
  const progress = max ? (value / max) * 100 : 0;

  return (
    <View
      className="rounded-lg p-3 gap-1"
      style={{ backgroundColor: colors.surface }}
    >
      <View className="flex-row items-center gap-1">
        <Text className="text-lg">{icon}</Text>
        <Text className="text-xs font-semibold text-muted">{label}</Text>
      </View>
      <Text className="text-lg font-bold" style={{ color }}>
        {value}
        {max && `/${max}`}
      </Text>
      {max && (
        <View
          className="h-1.5 bg-gray-300 rounded-full overflow-hidden"
          style={{ backgroundColor: colors.border }}
        >
          <View
            className="h-full rounded-full"
            style={{ width: `${progress}%`, backgroundColor: color }}
          />
        </View>
      )}
    </View>
  );
}

interface InfoRowProps {
  label: string;
  value: string;
}

function InfoRow({ label, value }: InfoRowProps) {
  return (
    <View className="flex-row justify-between items-center">
      <Text className="text-sm text-muted">{label}</Text>
      <Text className="text-sm font-bold text-foreground">{value}</Text>
    </View>
  );
}
